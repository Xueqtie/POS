import sqlite3
import os
from datetime import datetime, timedelta

DB_PATH = os.path.join(os.path.dirname(__file__), 'database', 'pos.db')

def seed_data():
    if not os.path.exists(DB_PATH):
        print(f"Error: Database not found at {DB_PATH}. Please run app.py first.")
        return

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    print("Cleaning old sales data...")
    cursor.execute("DELETE FROM sale_items")
    cursor.execute("DELETE FROM sales")

    # Generate historical sales for the last 7 days
    # We'll create a slight upward trend to make the AI prediction look logical
    base_revenue = 5000.00
    growth = 1200.00
    
    print("Generating 7 days of historical sales data...")
    for i in range(7, 0, -1):
        # Calculate date for i days ago
        past_date = (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d %H:%M:%S')
        # Revenue with a bit of randomness but general growth
        daily_total = base_revenue + ((7 - i) * growth) + (i * 150) 
        
        cursor.execute(
            "INSERT INTO sales (sale_date, total_amount, payment_method) VALUES (?, ?, ?)",
            (past_date, daily_total, 'Cash')
        )
        sale_id = cursor.lastrowid
        
        # Add a placeholder item for each sale so reports also work
        cursor.execute(
            "INSERT INTO sale_items (sale_id, product_id, quantity, unit_price, subtotal) VALUES (?, ?, ?, ?, ?)",
            (sale_id, 1, 1, daily_total, daily_total)
        )

    conn.commit()
    conn.close()
    print("Successfully seeded 7 days of sales data with a growth trend!")

if __name__ == "__main__":
    seed_data()
