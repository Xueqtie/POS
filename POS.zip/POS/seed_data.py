import pymysql

def reset_and_seed():
    try:
        conn = pymysql.connect(
            host="::1",
            user="root",
            password="",
            database="pos_system",
            charset="utf8mb4"
        )
        cursor = conn.cursor()
        
        
        cursor.execute("SET FOREIGN_KEY_CHECKS = 0")
        cursor.execute("TRUNCATE TABLE sale_items")
        cursor.execute("TRUNCATE TABLE sales")
        cursor.execute("TRUNCATE TABLE products")
        cursor.execute("SET FOREIGN_KEY_CHECKS = 1")
        
        
        items = [
            ('Mechanical Keyboard', 'Electronics', 2500.00, 50),
            ('Wireless Mouse', 'Electronics', 850.00, 100),
            ('Gaming Headset', 'Accessories', 3200.00, 30),
            ('USB-C Hub', 'Accessories', 1200.00, 40)
        ]
        
        cursor.executemany(
            "INSERT INTO products (name, category, price, stock_qty) VALUES (%s, %s, %s, %s)",
            items
        )

        
        
        cursor.execute("INSERT INTO sales (sale_date, total_amount) VALUES (DATE_SUB(NOW(), INTERVAL 2 DAY), 5000.00)")
        
        cursor.execute("INSERT INTO sales (sale_date, total_amount) VALUES (DATE_SUB(NOW(), INTERVAL 1 DAY), 7500.00)")
        
        cursor.execute("INSERT INTO sales (sale_date, total_amount) VALUES (NOW(), 12000.00)")
        
        conn.commit()
        print("Database reset with general items!")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        if 'conn' in locals() and conn.open:
            cursor.close()
            conn.close()

if __name__ == "__main__":
    reset_and_seed()
