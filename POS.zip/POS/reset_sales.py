import pymysql

def reset_sales():
    try:
        conn = pymysql.connect(
            host="::1",
            user="root",
            password="",
            database="pos_system",
            charset="utf8mb4"
        )
        cursor = conn.cursor()
        
        
        cursor.execute("SET FOREIGN_KEY_CHECKS = 0")
        cursor.execute("TRUNCATE TABLE sale_items")
        cursor.execute("TRUNCATE TABLE sales")
        cursor.execute("SET FOREIGN_KEY_CHECKS = 1")
        
        conn.commit()
        print("Sales data wiped successfully. System is back to zero!")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        if 'conn' in locals() and conn.open:
            cursor.close()
            conn.close()

if __name__ == "__main__":
    reset_sales()
