"""
Run this once to initialize the SQLite database.
The database file will be created at: database/pos.db
"""
import sqlite3, os

DB_PATH = os.path.join(os.path.dirname(__file__), 'database', 'pos.db')

def init_database():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT,
            price REAL NOT NULL,
            stock_qty INTEGER NOT NULL,
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS sales (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sale_date TEXT DEFAULT (datetime('now')),
            total_amount REAL NOT NULL,
            payment_method TEXT DEFAULT 'Cash'
        );
        CREATE TABLE IF NOT EXISTS sale_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sale_id INTEGER,
            product_id INTEGER,
            quantity INTEGER NOT NULL,
            unit_price REAL NOT NULL,
            subtotal REAL NOT NULL,
            FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
            FOREIGN KEY (product_id) REFERENCES products(id)
        );
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            staff_name TEXT NOT NULL,
            check_in TEXT DEFAULT (datetime('now')),
            check_out TEXT NULL
        );
    """)
    existing = conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
    if existing == 0:
        conn.executemany(
            "INSERT INTO products (name, category, price, stock_qty) VALUES (?, ?, ?, ?)",
            [
                ('Mechanical Keyboard', 'Electronics', 2500.00, 50),
                ('Wireless Mouse',      'Electronics',  850.00, 100),
                ('Gaming Headset',      'Accessories', 3200.00,  30),
                ('USB-C Hub',           'Accessories', 1200.00,  40),
            ]
        )
    conn.commit()
    conn.close()
    print("Database initialized successfully!")

if __name__ == "__main__":
    init_database()
