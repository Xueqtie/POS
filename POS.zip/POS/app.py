import os
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, jsonify
from datetime import datetime
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression

app = Flask(__name__)

# Register a custom filter to handle SQLite date strings
@app.template_filter('strftime')
def _jinja2_filter_datetime(date_str, fmt=None):
    if not date_str:
        return ""
    if isinstance(date_str, str):
        # Handle SQLite format: 'YYYY-MM-DD HH:MM:SS'
        try:
            # First try with seconds
            date_obj = datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S')
        except ValueError:
            try:
                # Then try with microseconds if present
                date_obj = datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S.%f')
            except ValueError:
                return date_str # Return original if parsing fails
    else:
        date_obj = date_str
    
    return date_obj.strftime(fmt or '%Y-%m-%d %H:%M')

DB_PATH = os.path.join(os.path.dirname(__file__), 'database', 'pos.db')

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # returns dict-like rows
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.executescript("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT,
            price REAL NOT NULL,
            stock_qty INTEGER NOT NULL,
            created_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS sales (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sale_date TEXT DEFAULT (datetime('now')),
            total_amount REAL NOT NULL,
            payment_method TEXT DEFAULT 'Cash'
        );

        CREATE TABLE IF NOT EXISTS sale_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sale_id INTEGER,
            product_id INTEGER,
            quantity INTEGER NOT NULL,
            unit_price REAL NOT NULL,
            subtotal REAL NOT NULL,
            FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
            FOREIGN KEY (product_id) REFERENCES products(id)
        );

        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            staff_name TEXT NOT NULL,
            check_in TEXT DEFAULT (datetime('now')),
            check_out TEXT NULL
        );
    """)

    # Seed sample products if empty
    existing = cursor.execute("SELECT COUNT(*) FROM products").fetchone()[0]
    if existing == 0:
        cursor.executemany(
            "INSERT INTO products (name, category, price, stock_qty) VALUES (?, ?, ?, ?)",
            [
                ('Mechanical Keyboard', 'Electronics', 2500.00, 50),
                ('Wireless Mouse',      'Electronics',  850.00, 100),
                ('Gaming Headset',      'Accessories', 3200.00,  30),
                ('USB-C Hub',           'Accessories', 1200.00,  40),
            ]
        )

    conn.commit()
    conn.close()

# ── Routes ────────────────────────────────────────────────────────────────────

@app.route('/')
def dashboard():
    conn = get_db_connection()
    total_products = conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
    total_sales    = conn.execute("SELECT COALESCE(SUM(total_amount),0) FROM sales").fetchone()[0]
    low_stock      = conn.execute("SELECT COUNT(*) FROM products WHERE stock_qty < 10").fetchone()[0]
    recent_sales   = conn.execute("SELECT * FROM sales ORDER BY sale_date DESC LIMIT 5").fetchall()
    conn.close()
    return render_template('dashboard.html',
                           total_products=total_products,
                           total_sales=total_sales,
                           low_stock=low_stock,
                           recent_sales=recent_sales)

@app.route('/reports')
def reports():
    conn = get_db_connection()
    performance = conn.execute("""
        SELECT p.name, SUM(si.quantity) as total_qty, SUM(si.subtotal) as total_rev
        FROM sale_items si
        JOIN products p ON si.product_id = p.id
        GROUP BY p.name
        ORDER BY total_rev DESC
    """).fetchall()
    conn.close()
    return render_template('reports.html', performance=performance)

@app.route('/products', methods=['GET', 'POST'])
def products():
    conn = get_db_connection()
    if request.method == 'POST':
        conn.execute(
            "INSERT INTO products (name, category, price, stock_qty) VALUES (?, ?, ?, ?)",
            (request.form['name'], request.form['category'],
             request.form['price'], request.form['stock'])
        )
        conn.commit()
        conn.close()
        return redirect(url_for('products'))

    products_list = conn.execute("SELECT * FROM products").fetchall()
    conn.close()
    return render_template('products.html', products=products_list)

@app.route('/restock', methods=['POST'])
def restock():
    conn = get_db_connection()
    conn.execute(
        "UPDATE products SET stock_qty = stock_qty + ? WHERE id = ?",
        (int(request.form['quantity']), request.form['product_id'])
    )
    conn.commit()
    conn.close()
    return redirect(url_for('products'))

@app.route('/delete_product/<int:id>')
def delete_product(id):
    conn = get_db_connection()
    conn.execute("DELETE FROM products WHERE id = ?", (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('products'))

@app.route('/sales', methods=['GET', 'POST'])
def sales():
    conn = get_db_connection()
    if request.method == 'POST':
        cart  = request.json['cart']
        total = request.json['total']

        cursor = conn.execute("INSERT INTO sales (total_amount) VALUES (?)", (total,))
        sale_id = cursor.lastrowid

        for item in cart:
            conn.execute(
                "INSERT INTO sale_items (sale_id, product_id, quantity, unit_price, subtotal) VALUES (?, ?, ?, ?, ?)",
                (sale_id, item['id'], item['qty'], item['price'], item['qty'] * item['price'])
            )
            conn.execute(
                "UPDATE products SET stock_qty = stock_qty - ? WHERE id = ?",
                (item['qty'], item['id'])
            )

        conn.commit()
        conn.close()
        return jsonify({"status": "success", "sale_id": sale_id})

    products_available = conn.execute("SELECT * FROM products WHERE stock_qty > 0").fetchall()
    conn.close()
    return render_template('sales.html', products=products_available)

@app.route('/predictions')
def predictions():
    conn = get_db_connection()
    df = pd.read_sql_query("""
        SELECT DATE(sale_date) as date, SUM(total_amount) as daily_total
        FROM sales
        GROUP BY DATE(sale_date)
        ORDER BY date ASC
    """, conn)
    conn.close()

    prediction_val = None
    if len(df) > 1:
        df['day_index'] = np.arange(len(df))
        model = LinearRegression()
        model.fit(df[['day_index']], df['daily_total'])
        next_day = len(df)
        prediction_val = round(max(0, model.predict([[next_day]])[0]), 2)

    return render_template('predictions.html', prediction=prediction_val)

@app.route('/attendance', methods=['GET', 'POST'])
def attendance():
    conn = get_db_connection()
    if request.method == 'POST':
        conn.execute("INSERT INTO attendance (staff_name) VALUES (?)", (request.form['name'],))
        conn.commit()
        conn.close()
        return redirect(url_for('attendance'))

    records = conn.execute("SELECT * FROM attendance ORDER BY check_in DESC").fetchall()
    conn.close()
    return render_template('attendance.html', records=records)

# ── Startup ───────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    init_db()
    print("=" * 50)
    print("  POS Pro AI System")
    print("  Open your browser at: http://127.0.0.1:5000")
    print("=" * 50)
    app.run(debug=True, port=5000)
