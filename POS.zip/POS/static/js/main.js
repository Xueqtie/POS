document.addEventListener('DOMContentLoaded', () => {
    // Current Path Highlight
    const path = window.location.pathname;
    const navLinks = {
        '/': 'nav-dashboard',
        '/products': 'nav-products',
        '/sales': 'nav-sales',
        '/reports': 'nav-reports',
        '/predictions': 'nav-predictions',
        '/attendance': 'nav-attendance'
    };
    
    if (navLinks[path]) {
        document.getElementById(navLinks[path]).classList.add('active');
    }
});
