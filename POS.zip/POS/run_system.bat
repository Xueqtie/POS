@echo off
title POS Pro AI System
color 0A
echo.
echo  ================================================
echo   POS Pro AI System - Starting...
echo  ================================================
echo.
echo  No XAMPP needed! Running with built-in database.
echo.

cd /d "C:\xampp\htdocs\POS"

start "" "http://127.0.0.1:5000"
python app.py

echo.
echo  Server stopped.
pause
